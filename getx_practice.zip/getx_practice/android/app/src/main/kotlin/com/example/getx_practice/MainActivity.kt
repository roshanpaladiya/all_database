package com.example.getx_practice

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
