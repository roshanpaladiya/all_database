class FirebaseResources {
  static const allSignUpUsersFirebaseKey =  'AllSignUpUsers';
  static  const signUpUserFirebaseKey =  'signUpUser';
}