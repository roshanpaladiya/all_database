class ApiResources{
  static const baseLink ='https://fakestoreapi.com/';
  static const url = '${baseLink}products';
}