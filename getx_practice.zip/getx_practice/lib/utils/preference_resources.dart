class PreferenceResources{
  static const isSignUp= 'signUp';
  static const signUpUser = 'signUpUser';
  static const  signUpUserList = 'signUpUserList';
  static const loginUser = 'loginUser';
  static const loginUserKey ='loginUserKey';
}