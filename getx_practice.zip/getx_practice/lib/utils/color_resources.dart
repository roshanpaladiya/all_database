import 'package:flutter/material.dart';

class ColorResources {
  static const redColor = Colors.red;
  static const greenColor = Colors.green;
}