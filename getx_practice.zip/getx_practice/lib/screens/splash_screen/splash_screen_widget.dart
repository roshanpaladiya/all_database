import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:getx_practice/screens/splash_screen/splash_screen_controller.dart';
import 'package:getx_practice/utils/string_resources.dart';

import '../sign_up_screen/sign_up_screen_controller.dart';

AppBar appbarSplashScreen() {
  return AppBar(
    centerTitle: true,
    title: const Text(StringResources.splashScreenText),
  );
}

Widget textField(){
  return GetBuilder<SplashScreenController>(builder: (controller) => TextField(controller: controller.number));
}
Widget otpButton() {
  return GetBuilder<SplashScreenController>(
    builder: (controller) => TextButton(
        onPressed: () => controller.otp(),
        child: Text(
          'otp',
          style: TextStyle(fontSize: 25),
        )),
  );
}
